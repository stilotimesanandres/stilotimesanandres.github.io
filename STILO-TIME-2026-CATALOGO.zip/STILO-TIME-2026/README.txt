# STILO-TIME 2026 — Catálogo web

## Cómo actualizarlo
1. Abre la carpeta `assets/images/` y reemplaza/agrega tus fotos.
2. Abre `data.js`.
3. En `products` agrega productos siguiendo el mismo formato.
4. En `gallery` agrega fotos siguiendo el mismo formato.
5. En `videos` agrega videos MP4 o cambia `type` a `youtube` y coloca el enlace/embed.
6. Abre `index.html` en el navegador para probar.

## Redes ya conectadas
- WhatsApp: 311 753 6876
- Facebook: Stilo Time San Andrés
- Instagram: @stilotimesanandres
- TikTok: @stilo.time.san.an

## Importante
La página funciona como catálogo estático: no necesita base de datos para empezar. Más adelante se puede conectar a un dominio, hosting, formulario, inventario o panel de administración sin rehacer el diseño principal.
