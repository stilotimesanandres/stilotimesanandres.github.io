const $ = (s)=>document.querySelector(s);

function renderProducts(){
  const grid=$("#product-grid");
  grid.innerHTML=STILO_DATA.products.map(p=>`
    <article class="product">
      <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.display='none'">
      <div class="product-info"><h3>${p.name}</h3><p>${p.description}</p><span class="tag">${p.tag||"STILO-TIME"}</span></div>
    </article>`).join("");
}
function renderGallery(){
  const grid=$("#gallery-grid");
  grid.innerHTML=STILO_DATA.gallery.map(g=>`
    <figure class="polaroid-gallery ${g.tilt||""}">
      <img src="${g.image}" alt="${g.caption}" loading="lazy" data-full="${g.image}">
      <p>${g.caption}</p>
    </figure>`).join("");
}
function renderVideos(){
  const grid=$("#video-grid");
  grid.innerHTML=STILO_DATA.videos.map(v=>`
    <article class="video-card">
      ${v.type==="youtube"
        ? `<iframe src="${v.src}" title="${v.title}" loading="lazy" allowfullscreen></iframe>`
        : `<video controls preload="metadata" src="${v.src}"></video>`}
      <h3>${v.title}</h3><p>${v.description}</p>
    </article>`).join("");
}
renderProducts(); renderGallery(); renderVideos();

const menuBtn=$(".menu-btn"), nav=$("#nav");
menuBtn.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuBtn.setAttribute("aria-expanded",open)});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const lightbox=$("#lightbox"), lightboxImg=$("#lightbox-img");
document.addEventListener("click",(e)=>{
  const img=e.target.closest("[data-full]");
  if(img){lightboxImg.src=img.dataset.full;lightboxImg.alt=img.alt;lightbox.classList.add("open");lightbox.setAttribute("aria-hidden","false")}
});
function closeLightbox(){lightbox.classList.remove("open");lightbox.setAttribute("aria-hidden","true");lightboxImg.src=""}
$("#close-lightbox").addEventListener("click",closeLightbox);
lightbox.addEventListener("click",e=>{if(e.target===lightbox)closeLightbox()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeLightbox()});