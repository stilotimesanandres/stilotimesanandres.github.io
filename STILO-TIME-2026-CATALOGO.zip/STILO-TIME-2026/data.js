/*
  EDITAR ESTE ARCHIVO para agregar contenido.
  No necesitas tocar index.html, styles.css ni script.js.
*/
const STILO_DATA = {
  products: [
    {name:"Pantaloneta", description:"Producto de ejemplo — reemplaza esta foto y texto.", image:"assets/images/producto-01.jpg", tag:"NUEVO"},
    {name:"Short", description:"Producto de ejemplo — preparado para ampliar el catálogo.", image:"assets/images/producto-02.jpg", tag:"CATÁLOGO"},
    {name:"Nueva colección", description:"Agrega aquí una nueva referencia.", image:"assets/images/producto-03.jpg", tag:"2026"}
  ],
  gallery: [
    {image:"assets/images/galeria-01.jpg", caption:"San Andrés · STILO-TIME", tilt:"tilt-a"},
    {image:"assets/images/galeria-02.jpg", caption:"Hecho con pasión", tilt:"tilt-b"},
    {image:"assets/images/galeria-03.jpg", caption:"Estilo caribeño", tilt:"tilt-a"},
    {image:"assets/images/galeria-04.jpg", caption:"Nueva colección", tilt:"tilt-b"}
  ],
  videos: [
    {type:"local", src:"assets/videos/video-01.mp4", title:"Presentación STILO-TIME", description:"Reemplaza este archivo por tu video."},
    {type:"local", src:"assets/videos/video-02.mp4", title:"Proceso de confección", description:"Muestra tu trabajo y proceso creativo."},
    {type:"local", src:"assets/videos/video-03.mp4", title:"Nueva colección", description:"Promociona tus productos."}
  ]
};